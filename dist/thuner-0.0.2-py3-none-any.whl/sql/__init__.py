# import sys

# if sys.version_info < (3, 11):
#     warning = """ \n\n
#     Support for Python versions less than 3.11 is deprecated.
#     Version 1.5 of tobac will require Python 3.7 or later.
#    Python {py} detected. \n\n
#     """.format(
#         py=".".join(str(v) for v in sys.version_info[:3])
#     )

#     print(warning)

# # from .module import (
# #     function,
# # )

# # Set version number
# __version__ = "0.0.1"

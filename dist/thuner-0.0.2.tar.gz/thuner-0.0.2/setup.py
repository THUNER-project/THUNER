"""
Minimal setup file for backwards compatibility. Setup behaviour inherited from 
pyproject.toml using setuptools package.
"""

from setuptools import setup

setup()
